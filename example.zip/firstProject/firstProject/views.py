from django.shortcuts import render
from product.models import product
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from .forms import RegisterForm

def about(request):
    return render(request,"about.html")

def contact(request):
    return render(request,"contact.html")   

def home(request):
    return render(request,"index.html") 


def search(request):
    query=request.GET.get('query','')
    #print(query)
    products=product.pm.all().filter(product_name__icontains=query)
    return render(request,"search.html",{"allproducts":products})  


def register(request):
    if request.method=="POST":
        form=RegisterForm(request.POST)
        #form=UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form=RegisterForm()    
        #form=UserCreationForm()
    return render(request,"register.html",{"form":form})

def login(request):
    form=AuthenticationForm()
    return render(request,"login.html",{"form":form})              