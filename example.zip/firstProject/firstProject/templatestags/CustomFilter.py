"""from django import template
from datetime import datetime"""


"""RegisterFilter=template.Library()
def printDate():
    return datetime.now().strftime("%d-%m-%Y")

RegisterFilter.filter("PrintDate",printDate)""""    